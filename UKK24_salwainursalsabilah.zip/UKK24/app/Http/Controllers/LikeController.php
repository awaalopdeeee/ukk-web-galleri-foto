<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Facades\Auth;
use App\Models\foto;
use App\Models\user;
use App\Models\album;
use App\Models\Like;

class LikeController extends Controller
{
    public function lihatfoto($FotoID){
        if(session('user')){
            $galleryfoto = Foto::find($FotoID);
            $like = Like::all();
            $komentar = Komentar::where('FotoID', $FotoID)->get();
            $user = Userr::find($foto->UserID);
            $user2 = Userr::all();
    
            return view('home', compact('galleryfoto','like','komentar','user','user2'));
            
        }
    }
    
    public function like($FotoID)
    {
        $cek = Like::where('UserID',session('user')->UserID)
                    ->where('FotoID', $FotoID)
                    ->first();
    
            if(!$cek) {
            $data = new Like();
            $data->FotoID = $FotoID;
            $data->UserID = session('user')->UserID;
            $data->TanggalLike = date('Y-m-d'); 
            $data->save();
    
            return redirect()->back();
            }else{
                $cek->delete();
                return redirect()->back();
          }
    }
}