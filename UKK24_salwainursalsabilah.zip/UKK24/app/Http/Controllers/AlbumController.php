<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\album;

class AlbumController extends Controller
{
public function album(){
    if(session('user') !=null) {
        $album = Album::all();
        return view('album',['album' => $album]);

    }  else{
        return redirect('/login')->with('pesanbaru', 'Silahkan Login terlebih dahulu');
    }
}


public function aksialbum(Request $request) {
    $data = new album();
    $data -> NamaAlbum = $request->input('NamaAlbum'); 
    $data -> Deskripsi = $request->input('Deskripsi');
    $data -> TanggalDibuat = date('y-m-d');
    $data -> UserID = session('user')->UserID;
    $data -> save();
    
    return redirect('/album')->with('succes','Album berhassil ditambahkan!');
}

}