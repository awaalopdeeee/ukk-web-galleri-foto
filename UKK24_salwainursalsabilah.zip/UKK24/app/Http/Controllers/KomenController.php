<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Facades\Auth;
use App\Models\komentar;
use App\Models\Userr;
use App\Models\Foto;

class KomenController extends Controller
{
    public function tampilKomentar($FotoID)
    {
        if(session('user') != null) {
        $komentar = komentar::all();
        return view('komen', compact('komentar', 'FotoID'));
    }else {
        return redirect('/login')->with('pesanbaru', 'Silahkan Login Terlebih Dahulu 1');
        }
    }

    public function lihatKomentar($FotoID)
    {
        if(session('user') != null) {
            $komentar = komentar::all();
            return view('lihatkomen', compact('komentar', 'FotoID'));
        }else {
            return redirect('/login')->with('pesanbaru', 'Siahkan Login Terlebih Dahulu !');
        }
    }

    public function aksiTambahKomentar(Request $request,$FotoID)
    {
        $data = new komentar();
        $data -> IsiKomentar = $request->input('IsiKomentar');
        $data -> TanggalKomentar = date('Y-m-d');
        $data -> UserID = session ('user')->UserID;
        $data -> FotoID = $FotoID;
        $data -> save();

        return redirect ('/home')->with('pesanbaru', 'Komentar berhasil dikirim !');
    }
}