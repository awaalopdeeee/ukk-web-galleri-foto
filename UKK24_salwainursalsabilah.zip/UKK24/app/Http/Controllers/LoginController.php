<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\facades\Auth;
use App\Models\User;


class LoginController extends Controller
{
    public function tampil(){
        return view('login');
    }
    public function login(Request $request)
    {
            $request->validate([
                'Username' => 'required',
                'Password' => 'required',
            ]);

        $data = User::where('username', $request->input('Username'))
                    ->where('password', $request->input('Password'))
                    ->first();
        if($data === null) {
            return redirect('/login')->with('pesan', 'Username / Password Salah !');
        }else{
            session()->put('user', $data);
            return redirect('/home');
        }    
    }

}
