<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\foto;
use App\Models\user;
use App\Models\album;

class FotoController extends Controller
{
    public function foto()
    {
        if(session ('user') != null){
        $galleryfoto = Foto::all();
        return view('foto', ['galleryfoto' => $galleryfoto]);
       }else{
        return redirect('/login')->with('success', 'Album berhasil ditambahkan');
        
       }
    }

    public function home2()
    {
        if(session ('user') != null){
        $galleryfoto = Foto::all();
        return view('home', ['galleryfoto' => $galleryfoto]);
       }else{
        return redirect('/login')->with('success', 'Album berhasil ditambahkan');
        
       }
    }

    public function aksifoto(Request $request)
    {
        $filefoto =$request->file('foto');
        $filefoto->move('folder',$filefoto->getClientOriginalName());

        $data = new Foto();
        $data -> JudulFoto = $request->input('Judul');
        $data -> DeskripsiFoto = $request->input('Deskripsi');
        $data -> TanggalUnggah = date('Y-m-d');
        $data -> LokasiFile = '/folder/'.$filefoto->getClientOriginalName();
        $data -> UserID = session ('user')->UserID;
        $data -> AlbumID = 123;
        $data -> save();

        Session()->flash('success', 'Album Berhasil ditambahkan !');
        return redirect('/foto');
}
}

