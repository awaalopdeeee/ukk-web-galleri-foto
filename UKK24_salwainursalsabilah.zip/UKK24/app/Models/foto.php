<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class foto extends Model
{
    public $timestamps = false;
    protected $table = 'galleryfoto';
    protected $guarted = [];
    protected $primaryKey = 'FotoID';
}
