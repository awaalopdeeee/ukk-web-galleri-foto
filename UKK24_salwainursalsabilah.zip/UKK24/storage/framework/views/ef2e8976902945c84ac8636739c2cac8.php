<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Komentar</title>
<style>
    /* Style untuk tampilan komentar */
    .komentar {
        margin-bottom: 10px;
        border: 1px solid #ccc;
        padding: 10px;
    }
</style>
</head>
<body>

<h1>Komentar</h1>

<!-- Daftar komentar -->
<div id="daftar-komentar"></div>

<!-- Form untuk menulis komentar -->
<form id="form-komentar">
    <textarea id="input-komentar" placeholder="Tulis komentar Anda di sini..." required></textarea>
    <input type="text" id="nama-pengguna" placeholder="Nama Anda" required>
    <button type="submit">Kirim Komentar</button>
</form>

<script>
document.getElementById("form-komentar").addEventListener("submit", function(event) {
    event.preventDefault(); // Mencegah pengiriman form standar

    // Mengambil nilai komentar dan nama pengguna dari form
    var komentar = document.getElementById("input-komentar").value;
    var namaPengguna = document.getElementById("nama-pengguna").value;

    // Menambahkan komentar ke dalam daftar komentar
    var daftarKomentar = document.getElementById("daftar-komentar");
    var komentarElement = document.createElement("div");
    komentarElement.classList.add("komentar");
    komentarElement.innerHTML = "<strong>" + namaPengguna + ":</strong> " + komentar;
    daftarKomentar.appendChild(komentarElement);

    // Mengosongkan input setelah komentar dikirim
    document.getElementById("input-komentar").value = "";
    document.getElementById("nama-pengguna").value = "";
});
</script>

</body>
</html>
<?php /**PATH C:\Users\asus\UKK24\resources\views/kmn.blade.php ENDPATH**/ ?>