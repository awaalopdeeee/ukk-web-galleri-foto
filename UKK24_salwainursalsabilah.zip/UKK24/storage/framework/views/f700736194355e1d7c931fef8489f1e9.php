<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selamat Datang!</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
  body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            background-image: url('bg.jpg')
        }
        
    .welcome-text {
      text-align: center;
      color: 	black;
    }

    .welcome-text h1 {
      font-size: 36px;
      margin-bottom: 20px;
    }

    .welcome-text p {
      font-size: 18px;
    }
.height{

    height: 100vh;
}

.form{
  width: 50%;
margin: top;
    position: relative;
}

.form .fa-search{

    position: absolute;
    top:20px;
    left: 20px;
    color: #9ca3af;

}

.gallery {
            column-count: 3; /* Menentukan jumlah kolom */
            column-gap: 15px; /* Menentukan jarak antar kolom */
            max-width: 1200px; /* Menentukan lebar maksimum galeri */
            margin: 20px auto; /* Memberikan margin pada galeri */
        }

        .gallery img {
            width: 23rem;
            height: 20rem;
            margin-bottom: 15px;
            display: block;
            border-radius: 10%;
        }

        p{
          text-align: center;
        }

.form span{

        position: absolute;
    right: 17px;
    top: 13px;
    padding: 2px;
    border-left: 1px solid #d1d5db;

}

.left-pan{
    padding-left: 7px;
}

.left-pan i{
   
   padding-left: 10px;
}

.form-input{

    height: 55px;
    text-indent: 33px;
    border-radius: 10px;
}

.form-input:focus{

    box-shadow: none;
    border:none;
}

.navbar{
    background-color: #808080;
}

    .gallery img:hover {
      transform: scale(1.05);
    }
</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>

<nav class="navbar navbar-expand-lg p-3">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">GALLERY PHOTO</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="login">Log In</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="register">Register</a>
          </li>
        </ul>
      </div>
    </div>
    </nav>
    </div>
<br>
<br>
<br>
    <div class="welcome-text">
    <h1>Selamat Datang!</h1>
    <h6>Ini adalah Halaman Sambutan, simpan kenangan anda bersama orang terdekat disini:)</h6>
  </div>
<br>
<div class="image-container">
  <div class="gallery">
    <img src="1.jpeg" alt="Image 1">
    <img src="2.jpeg" alt="Image 2">
    <img src="3.jpeg" alt="Image 3">
    <img src="4.jpeg" alt="Image 1">
    <img src="5.jpeg" alt="Image 2">
    <img src="6.jpeg" alt="Image 3">
</div>
</div>



</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>


</body>
</html><?php /**PATH C:\Users\asus\UKK24\resources\views/awal.blade.php ENDPATH**/ ?>