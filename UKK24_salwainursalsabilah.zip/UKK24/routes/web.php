<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\AlbumController;
use App\Http\Controllers\FotoController;
use App\Http\Controllers\LikeController;
use App\Http\Controllers\KomenController;
use App\Models\album;
use App\Models\foto;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/home', function () {
    return view('home');
});

Route::get('/login', function () {
    return view('login');
});

Route::get('/register', function () {
    return view('register');
});

Route::get('/album', function () {
    return view('album');
});

Route::get('/foto', function () {
    return view('foto');
});

Route::get('/awal', function () {
    return view('awal');
});

Route::get('/tambahalbum', function () {
    return view('tambahalbum');
});

Route::get('/tambahft', function () {
    return view('tambahft');
});

Route::get('/komen', function () {
    return view('komen');
});

Route::get('/lihatkomen', function () {
    return view('lihatkomen');
});

Route::get('/login',[LoginController::class, 'tampil']);
Route::post('/home',[LoginController::class, 'login']);

Route::get('/register',[RegisterController::class, 'tampil']);
Route::post('/login',[RegisterController::class, 'aksiregister']);

Route::get('/album', [AlbumController::class, 'album']);
Route::post('/album', [AlbumController::class, 'aksialbum']);

Route::get('/foto', [FotoController::class, 'foto']);
Route::get('/home', [FotoController::class, 'home2']);
Route::post('/foto', [FotoController::class, 'aksifoto']);

Route::get('/home/{FotoID}', [LikeController::class, 'lihatFoto']);
Route::post('/berilike/{FotoID}', [LikeController::class, 'like']);

Route::get('/komen/{FotoID}', [KomenController::class, 'tampilKomentar']);
Route::post('/lihatkomen/{FotoID}', [KomenController::class, 'aksiTambahKomentar']);
Route::get('/lihatkomen/{FotoID}', [KomenController::class, 'lihatKomentar']);