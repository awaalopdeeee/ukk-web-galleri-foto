<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Album</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
  body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: #D3D3D3;
}

.height{

    height: 100vh;
}

.navbar{
    background-color: #808080;
}

img{
    width: 20rem;
    height: 20rem;
}



button{
    background-color: #808080;
    border-radius: 20px;
    color: black;
    border-color: white;
    width: 8rem;
    height: rem;
}

.gallery-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px; /* This adds space between the cards */
            justify-content: center; /* This centers the cards in the middle of the page */
        }

        .card {
            width: 17rem;
            text-align: center;
            margin-bottom: 15px; /* Adds some space below each card */
        }

        .card-img-top {
            width: auto;
            height: auto;
            border-radius: 20%; /* Adjust if you want rounded corners for your images */
      }

      .btn{
        background-color: #808080;
        border-color: #d3d3d3;
      }

      .btn:hover{
        background-color: #808080;
        border-color: #d3d3d3;
      }

      .container{
        display: grid;
      }

</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

<link rel="icon" href="/docs/5.3/assets/img/favicons/favicon.ico">
<meta name="theme-color" content="#712cf9">

    
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>

<nav class="navbar navbar-expand-lg p-3">
      <b><a class="navbar-brand" href="#">GALLERY PHOTO</a></b>
                &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp;
                &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; 
                &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; 
                &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; &emsp; 
                <a href="/tambahalbum">
                <button type="tmbhalbum">Buat Album</button></a>
      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="home">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="awal">Logout</a>
          </li>
        </ul>
      </div>
    </div>
    </nav>
    </div>
    <br>
    <br>
    <div class="container mt-4">
    <div class="gallery-row">
      @foreach($album as $item)
      @if(session()->get('user')->UserID ==$item->UserID)
    <div class="card">
  <img src="hhe.jpeg" class="card-img-top">
  <div class="card-body">
    <h3 class="card-title">{{$item->NamaAlbum}}</h3>
    <p class="card-text">{{ $item->Deskripsi}}</p>
    <p class="card-text">{{ $item->TanggalDibuat}}</p>
    <a href="/foto" class="btn btn-primary">Lihat Album</a>
  </div>
  </div>
  @endif
  @endforeach
  </div>
  </div>
</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>


</body>
</html>