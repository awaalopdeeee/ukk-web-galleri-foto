<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<style>
  body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #d3d3d3;
        }

        .gallery {
      display: flex;
      flex-wrap: wrap;
      justify-content: space-around;
    }

    .gallery img {
      width: 270px;
      height: 300px;
      margin: 10px;
      object-fit: cover;
      cursor: pointer;
      border: 2px solid #808080;
      border-radius: 8px;
    }
/* Add this to your existing styles */
.form {
  display: flex;
  align-items: center;
  justify-content: center;
}

.form i {
  font-size: 24px; /* Adjust icon size as needed */
  margin-right: 10px; /* Adjust icon margin as needed */
}

.form-input {
  width: 300px; /* Adjust input width as needed */
  height: 40px; /* Adjust input height as needed */
  border: 2px solid #d63031; /* Warna pink */
  border-radius: 20px; /* Adjust border-radius as needed */
  padding: 5px 10px; /* Adjust padding as needed */
  font-size: 16px; /* Adjust font size as needed */
}
.gallery-row {
            display: flex;
            flex-wrap: wrap;
            gap: 15px; /* This adds space between the cards */
            justify-content: center; /* This centers the cards in the middle of the 
            page */
        }

.card {
    width: 18rem;
    text-align: center;
    margin-bottom: 15px; /* Adds some space below each card */
}

.card-img-top {
    width: 100%;
    height: auto;
    border-radius: 20%; /* Adjust if you want rounded corners for your images */
}

/* Reset styling */
* {
margin: 0;
padding: 0;
box-sizing: border-box;
}

/* Style button */
.styled-button {
    display: inline-block;
    padding: 10px 10px;
    font-size: 16px;
    text-align: center;
    text-decoration: none;
    cursor: pointer;
    background-color: #808080; /* Warna latar belakang */
    color: #ffffff; /* Warna teks */
    border-radius: 5px; /* Sudut melengkung */
    transition: background-color 0.3s ease;
}

/* Hover effect */
.styled-button:hover {
    background-color: #808080; /* Warna latar belakang saat dihover */
}

.height{

    height: 100vh;
}

.left-pan{
    padding-left: 7px;
}

.left-pan i{
   
   padding-left: 10px;
}

.navbar{
    background-color: #808080;
}

.btn-nme{
  background-color: #808080;
  border-radius: 5px;
}

.image-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
      grid-gap: 20px;
      padding: 20px;
      justify-content: center;
    }

    .image-container {
      text-align: center;
    }

    .image-container img {
      width: 100%;
      max-width: 300px; /* Maksimum lebar gambar */
      border-radius: 10px;
      margin-bottom: 10px;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      transition: transform 0.3s ease;
    }

    .image-container img:hover {
      transform: scale(1.05);
    }

    .image-container h3 {
      margin: 5px 0;
      color: #333;
      font-family: 'Arial', sans-serif;
    }

    .image-container p {
      color: #777;
      font-family: 'Georgia', serif;
    }

</style>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <!-- Custom styles for this template -->
    <link href="headers.css" rel="stylesheet">
  </head>
  <body>

<nav class="navbar navbar-expand-lg p-3">
      <b><a class="navbar-brand" href="#">GALLERY PHOTO</a></b>
      <div class=" collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav ms-auto ">
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="/album">Album</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-2 active" aria-current="page" href="/awal">Logout</a>
          </li>
          <li>
          <button class="btn-nme">@ {{(Session()->get('user')->Username)}}</button>
          </li>
        </ul>
      </div>
    </div>
    </nav>
    </div>
    <br>
    <div class="image-grid">
@foreach( $galleryfoto as $item)
<div class="image-container">
<img src="{{ $item->LokasiFile }}" alt="Foto 1">
    <h3 class="card-title" style="color:black">{{$item->JudulFoto}}</h3>
    <p class="card-text" style="color:black">{{ $item->DeskripsiFoto}}</p>
    <p class="card-text" style="color:black">{{ $item->TanggalUnggah}}</p>
    <form action="/berilike/{{ $item->FotoID }}" method="post">
                              @csrf
                              
                              @php
                              $cek = \App\Models\Like::where('UserID', session('user')->UserID)
                                    ->where('FotoID', $item->FotoID)
                                    ->first();

                              $warna = 'red';
                              if(!$cek)  {
                                 $warna = 'black';
                              }
                              @endphp
                              
    <button type="submit" class="styled-button" style="color:{{ $warna }}">
    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-heart-fill" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314"/>
</svg>Like</button>


<a href="/komen/{{ $item->FotoID }}" class="styled-button" type="submit">
<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-chat-dots" viewBox="0 0 16 16">
  <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0m4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0m3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2"/>
  <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9 9 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.4 10.4 0 0 1-.524 2.318l-.003.011a11 11 0 0 1-.244.637c-.079.186.074.394.273.362a22 22 0 0 0 .693-.125m.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6-3.004 6-7 6a8 8 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a11 11 0 0 0 .398-2"/>
</svg>Komentar </a>
<a href="/lihatkomen/{{ $item->FotoID }}" class="styled-button">{{\App\Models\Komentar::where('FotoID', $item->FotoID)->count()}}
</a>
</form>
                            </div>
    @endforeach
</main>
</div>
<script src="/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>



</body>
</html>